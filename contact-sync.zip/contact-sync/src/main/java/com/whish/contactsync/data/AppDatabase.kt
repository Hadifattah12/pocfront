package com.whish.contactsync.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters

@Database(
    entities = [ContactSnapshot::class, PendingSyncChunk::class],
    version = 5,
    exportSchema = false
)
@TypeConverters(ContactPayloadListConverter::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun contactDao(): ContactDao
    abstract fun pendingSyncChunkDao(): PendingSyncChunkDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "contact_sync_database"
                )
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
