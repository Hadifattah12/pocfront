package com.test1.test1.dtos;

import lombok.Data;

@Data
public class ContactDto {

    private String contactName;

    // SHA-256 hash in hex format, 64 characters
    private String phoneNumber;

    // getters and setters
}
