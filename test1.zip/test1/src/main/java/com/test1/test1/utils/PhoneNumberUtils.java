package com.test1.test1.utils;

import com.google.i18n.phonenumbers.NumberParseException;
import com.google.i18n.phonenumbers.PhoneNumberUtil;
import com.google.i18n.phonenumbers.Phonenumber;

public class PhoneNumberUtils {

    private static final PhoneNumberUtil phoneUtil = PhoneNumberUtil.getInstance();

    public static String normalize(String phoneNumber, String region) {
        try {
            Phonenumber.PhoneNumber number = phoneUtil.parse(phoneNumber, region);

            if (!phoneUtil.isValidNumber(number)) {
                throw new IllegalArgumentException("INVALID_PHONE_NUMBER");
            }

            return phoneUtil.format(number, PhoneNumberUtil.PhoneNumberFormat.E164);

        } catch (NumberParseException e) {
            throw new IllegalArgumentException("INVALID_PHONE_NUMBER", e);
        }
    }
}