package com.test1.test1.enums;

public enum SyncSessionStatus {
    OPEN,
    COMPLETED,
    EXPIRED,
    FAILED
}
