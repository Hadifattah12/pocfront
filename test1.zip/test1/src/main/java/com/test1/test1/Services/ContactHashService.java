package com.test1.test1.Services;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;

@Service
public class ContactHashService {

    private final String secret;

    public ContactHashService(@Value("${contact-sync.hash-secret}") String secret) {
        this.secret = secret;
    }

    public byte[] hashPhoneNumber(String normalizedPhoneNumber) {
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            SecretKeySpec keySpec = new SecretKeySpec(
                    secret.getBytes(StandardCharsets.UTF_8),
                    "HmacSHA256"
            );

            mac.init(keySpec);

            return mac.doFinal(normalizedPhoneNumber.getBytes(StandardCharsets.UTF_8));
        } catch (Exception e) {
            throw new RuntimeException("FAILED_TO_HASH_PHONE_NUMBER", e);
        }
    }
}