package com.test1.test1.repositories;

import com.test1.test1.enums.SyncSessionStatus;
import com.test1.test1.models.SyncSession;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface SyncSessionRepository extends JpaRepository<SyncSession, Long> {

    Optional<SyncSession> findByUserIdAndClientSyncId(Long userId, String clientSyncId);

//  lock it so nobody else can touch it until I'm done
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("""
        SELECT s
        FROM SyncSession s
        WHERE s.id = :sessionId
        AND s.userId = :userId
    """)
    Optional<SyncSession> findByIdAndUserIdForUpdate(
            @Param("sessionId") Long sessionId,
            @Param("userId") Long userId
    );

    List<SyncSession> findByStatusInAndExpiresAtBefore(
            List<SyncSessionStatus> statuses,
            LocalDateTime before
    );
}
