package com.test1.test1.dtos;

import com.test1.test1.enums.SyncSessionStatus;
import com.test1.test1.enums.SyncType;
import lombok.Data;

@Data
public class SyncSessionResponse {

    private Long sessionId;
    private String clientSyncId;
    private SyncSessionStatus status;
    private SyncType syncType;
    private Integer chunkSize;
    private Integer nextExpectedChunkIndex;
    private Integer totalExpectedChunks;
    private String expiresAt;

    // getters and setters
}
