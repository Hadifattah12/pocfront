package com.test1.test1.Services;

import com.test1.test1.dtos.*;
import com.test1.test1.enums.ContactStatus;
import com.test1.test1.enums.SyncSessionStatus;
import com.test1.test1.mappers.SyncSessionMapper;
import com.test1.test1.models.SyncSession;
import com.test1.test1.models.UserContact;
import com.test1.test1.repositories.SyncSessionRepository;
import com.test1.test1.repositories.UserContactRepository;
import com.test1.test1.utils.PhoneNumberUtils;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
public class ContactSyncService {

    private static final int CHUNK_SIZE = 100;
    private static final int SESSION_EXPIRY_MINUTES = 30;

    private final SyncSessionMapper syncSessionMapper;
    private final SyncSessionRepository syncSessionRepository;
    private final UserContactRepository userContactRepository;
    private final ContactHashService contactHashService;

    public ContactSyncService(
            SyncSessionRepository syncSessionRepository,
            UserContactRepository userContactRepository,
            SyncSessionMapper syncSessionMapper,
            ContactHashService contactHashService
    ) {
        this.syncSessionRepository = syncSessionRepository;
        this.userContactRepository = userContactRepository;
        this.syncSessionMapper = syncSessionMapper;
        this.contactHashService = contactHashService;
    }

    @Transactional
    public SyncSessionResponse createSession(Long userId, CreateSyncSessionRequest request) {
        return syncSessionRepository
                .findByUserIdAndClientSyncId(userId, request.getClientSyncId())
                .map(syncSessionMapper::toResponse)
                .orElseGet(() -> createNewSessionIdempotently(userId, request));
    }

    private SyncSessionResponse createNewSessionIdempotently(
            Long userId,
            CreateSyncSessionRequest request
    ) {
        try {
            int totalExpectedChunks = calculateTotalExpectedChunks(request.getTotalChanges());

            SyncSession session = syncSessionMapper.toEntity(
                    request,
                    userId,
                    CHUNK_SIZE,
                    totalExpectedChunks,
                    LocalDateTime.now().plusMinutes(SESSION_EXPIRY_MINUTES)
            );

            return syncSessionMapper.toResponse(syncSessionRepository.save(session));
        } catch (DataIntegrityViolationException ex) {
            return syncSessionRepository
                    .findByUserIdAndClientSyncId(userId, request.getClientSyncId())
                    .map(syncSessionMapper::toResponse)
                    .orElseThrow(() -> ex);
        }
    }

    @Transactional
    public UploadChunkResponse uploadChunk(
            Long userId,
            Long sessionId,
            UploadChunkRequest request
    ) {
        SyncSession session = syncSessionRepository
                .findByIdAndUserIdForUpdate(sessionId, userId)
                .orElseThrow(() -> new RuntimeException("SESSION_NOT_FOUND"));

        if (session.getStatus() == SyncSessionStatus.COMPLETED) {
            return syncSessionMapper.toUploadChunkResponse(
                    session,
                    request.getChunkIndex(),
                    true
            );
        }

        validateSessionOpenAndNotExpired(session);
        validateChunkIndex(session, request.getChunkIndex());

        if (request.getChunkIndex() < session.getNextExpectedChunkIndex()) {
            return syncSessionMapper.toUploadChunkResponse(
                    session,
                    request.getChunkIndex(),
                    true
            );
        }

        saveAddedContacts(userId, request);
        saveUpdatedContacts(userId, request);
        saveDeletedContacts(userId, request);

        session.setNextExpectedChunkIndex(session.getNextExpectedChunkIndex() + 1);

        if (session.getTotalExpectedChunks().equals(session.getNextExpectedChunkIndex())) {
            session.setStatus(SyncSessionStatus.COMPLETED);
            session.setCompletedAt(LocalDateTime.now());

            // Later: publish SESSION_ENDED event
        }

        syncSessionRepository.save(session);

        return syncSessionMapper.toUploadChunkResponse(
                session,
                request.getChunkIndex(),
                false
        );
    }

    @Transactional(readOnly = true)
    public SyncSessionResponse getStatus(Long userId, Long sessionId) {
        SyncSession session = syncSessionRepository
                .findById(sessionId)
                .filter(s -> s.getUserId().equals(userId))
                .orElseThrow(() -> new RuntimeException("SESSION_NOT_FOUND"));

        return syncSessionMapper.toResponse(session);
    }


    private void saveAddedContacts(Long userId, UploadChunkRequest request) {
        if (request.getAdded() == null) return;

        for (ContactDto dto : request.getAdded()) {
            upsertActiveContact(userId, dto, request.getRegion());
        }
    }

    private void saveUpdatedContacts(Long userId, UploadChunkRequest request) {
        if (request.getUpdated() == null) return;

        for (ContactDto dto : request.getUpdated()) {
            byte[] hash = normalizeAndHash(dto.getPhoneNumber(), request.getRegion());

            userContactRepository
                    .findByOwnerUserIdAndContactPhoneHash(userId, hash)
                    .ifPresent(contact -> {
                        contact.setContactName(dto.getContactName());
                        userContactRepository.save(contact);
                    });
        }
    }

    private void saveDeletedContacts(Long userId, UploadChunkRequest request) {
        if (request.getDeleted() == null) return;

        for (ContactDto dto : request.getDeleted()) {
            byte[] hash = normalizeAndHash(dto.getPhoneNumber(), request.getRegion());

            userContactRepository
                    .findByOwnerUserIdAndContactPhoneHash(userId, hash)
                    .ifPresent(contact -> {
                        contact.setStatus(ContactStatus.DELETED);
                        userContactRepository.save(contact);
                    });
        }
    }

    private void upsertActiveContact(Long userId, ContactDto dto, String region) {
        byte[] hash = normalizeAndHash(dto.getPhoneNumber(), region);

        UserContact contact = userContactRepository
                .findByOwnerUserIdAndContactPhoneHash(userId, hash)
                .orElseGet(() -> {
                    UserContact newContact = new UserContact();
                    newContact.setOwnerUserId(userId);
                    newContact.setContactPhoneHash(hash);
                    return newContact;
                });

        contact.setContactName(dto.getContactName());
        contact.setStatus(ContactStatus.ACTIVE);

        userContactRepository.save(contact);
    }

    private byte[] normalizeAndHash(String phoneNumber, String region) {
        String normalized = PhoneNumberUtils.normalize(phoneNumber, region);
        return contactHashService.hashPhoneNumber(normalized);
    }

    private void validateSessionOpenAndNotExpired(SyncSession session) {
        if (session.getStatus() != SyncSessionStatus.OPEN) {
            throw new RuntimeException("SESSION_NOT_OPEN");
        }

        if (session.getExpiresAt().isBefore(LocalDateTime.now())) {
            session.setStatus(SyncSessionStatus.EXPIRED);
            syncSessionRepository.save(session);
            throw new RuntimeException("SESSION_EXPIRED");
        }
    }

    private void validateChunkIndex(SyncSession session, Integer chunkIndex) {
        if (chunkIndex == null || chunkIndex < 0) {
            throw new RuntimeException("INVALID_CHUNK_INDEX");
        }

        if (chunkIndex > session.getNextExpectedChunkIndex()) {
            throw new RuntimeException("CHUNK_OUT_OF_ORDER_EXPECTED_" + session.getNextExpectedChunkIndex());
        }
    }

    private int calculateTotalExpectedChunks(Integer totalChanges) {
        if (totalChanges == null || totalChanges <= 0) {
            return 0;
        }

        return (int) Math.ceil(totalChanges / (double) CHUNK_SIZE);
    }
}