package com.test1.test1.utils;

public class HashUtils {

    public static byte[] hexToBytes(String hex) {
        if (hex == null || hex.length() != 64) {
            throw new IllegalArgumentException("Invalid SHA-256 hash");
        }

        byte[] result = new byte[32];

        for (int i = 0; i < 32; i++) {
            int index = i * 2;
            result[i] = (byte) Integer.parseInt(hex.substring(index, index + 2), 16);
        }

        return result;
    }
}
