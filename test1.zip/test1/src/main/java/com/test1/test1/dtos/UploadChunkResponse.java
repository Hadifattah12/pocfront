package com.test1.test1.dtos;

import com.test1.test1.enums.SyncSessionStatus;
import lombok.Data;

@Data
public class UploadChunkResponse {

    private Boolean accepted;
    private Boolean duplicate;
    private Integer nextExpectedChunkIndex;
    private Long sessionId;
    private Integer chunkIndex;
    private SyncSessionStatus status;
    private Integer totalExpectedChunks;
    private Integer expectedChunks;

    // getters and setters
}
