package com.test1.test1.dtos;

import com.test1.test1.enums.SyncType;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class CreateSyncSessionRequest {

    @NotBlank
    private String clientSyncId;

    @NotNull
    private SyncType syncType;

    @NotNull
    private Integer totalChanges;

    // getters and setters
}
