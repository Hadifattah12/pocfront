package com.test1.test1.models;

import com.test1.test1.enums.SyncSessionStatus;
import com.test1.test1.enums.SyncType;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Getter
@Setter
@Entity
@Table(name = "sync_sessions")
public class SyncSession {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(name = "client_sync_id", nullable = false)
    private String clientSyncId;

    @Enumerated(EnumType.STRING)
    @Column(name = "sync_type", nullable = false)
    private SyncType syncType;

    @Column(name = "total_changes", nullable = false)
    private Integer totalChanges;

    @Column(name = "chunk_size", nullable = false)
    private Integer chunkSize;

    @Column(name = "total_expected_chunks", nullable = false)
    private Integer totalExpectedChunks;

    @Column(name = "next_expected_chunk_index", nullable = false)
    private Integer nextExpectedChunkIndex = 0;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private SyncSessionStatus status = SyncSessionStatus.OPEN;

    @Column(name = "expires_at", nullable = false)
    private LocalDateTime expiresAt;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "completed_at")
    private LocalDateTime completedAt;

    @PrePersist
    void prePersist() {
        createdAt = LocalDateTime.now();
    }

    // getters and setters
}
