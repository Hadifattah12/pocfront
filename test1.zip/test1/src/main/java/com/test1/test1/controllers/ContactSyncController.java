package com.test1.test1.controllers;

import com.test1.test1.Services.ContactSyncService;
import com.test1.test1.dtos.CreateSyncSessionRequest;
import com.test1.test1.dtos.SyncSessionResponse;
import com.test1.test1.dtos.UploadChunkRequest;
import com.test1.test1.dtos.UploadChunkResponse;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/contact-sync/sessions")
public class ContactSyncController {

    private final ContactSyncService contactSyncService;

    public ContactSyncController(ContactSyncService contactSyncService) {
        this.contactSyncService = contactSyncService;
    }

    @PostMapping
    public SyncSessionResponse createSession(
            @RequestHeader("X-User-Id") Long userId,
            @Valid @RequestBody CreateSyncSessionRequest request
    ) {
        return contactSyncService.createSession(userId, request);
    }

    @PostMapping("/{sessionId}/chunks")
    public UploadChunkResponse uploadChunk(
            @RequestHeader("X-User-Id") Long userId,
            @PathVariable Long sessionId,
            @Valid @RequestBody UploadChunkRequest request
    ) {
        return contactSyncService.uploadChunk(userId, sessionId, request);
    }

    @GetMapping("/{sessionId}/status")
    public SyncSessionResponse getStatus(
            @RequestHeader("X-User-Id") Long userId,
            @PathVariable Long sessionId
    ) {
        return contactSyncService.getStatus(userId, sessionId);
    }
}