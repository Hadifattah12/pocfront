package com.test1.test1.dtos;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.util.List;

@Data
public class UploadChunkRequest {

    @NotNull
    private Integer chunkIndex;
    private String region;

    private List<ContactDto> added;
    private List<ContactDto> updated;
    private List<ContactDto> deleted;

    // getters and setters
}
