package com.test1.test1.enums;

public enum SyncType {
    INITIAL,
    INCREMENTAL
}