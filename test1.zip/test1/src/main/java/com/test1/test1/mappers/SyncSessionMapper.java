package com.test1.test1.mappers;

import com.test1.test1.dtos.CreateSyncSessionRequest;
import com.test1.test1.dtos.SyncSessionResponse;
import com.test1.test1.dtos.UploadChunkResponse;
import com.test1.test1.enums.SyncSessionStatus;
import com.test1.test1.models.SyncSession;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.time.LocalDateTime;

//spring bean => inject using @Autowired
@Mapper(componentModel = "spring")
public interface SyncSessionMapper {

    @Mapping(target = "id", ignore = true)
    @Mapping(target = "userId", source = "userId")
    @Mapping(target = "clientSyncId", source = "request.clientSyncId")
    @Mapping(target = "syncType", source = "request.syncType")
    @Mapping(target = "totalChanges", source = "request.totalChanges")
    @Mapping(target = "chunkSize", source = "chunkSize")
    @Mapping(target = "nextExpectedChunkIndex", constant = "0")
    @Mapping(target = "status", constant = "OPEN")
    @Mapping(target = "expiresAt", source = "expiresAt")
    @Mapping(target = "createdAt", ignore = true)
    @Mapping(target = "completedAt", ignore = true)
    SyncSession toEntity(
            CreateSyncSessionRequest request,
            Long userId,
            Integer chunkSize,
            Integer totalExpectedChunks,
            LocalDateTime expiresAt
    );

    @Mapping(target = "sessionId", source = "id")
    @Mapping(target = "expiresAt", expression = "java(session.getExpiresAt().toString())")
    SyncSessionResponse toResponse(SyncSession session);

//  always set to true
    @Mapping(target = "accepted", constant = "true")
    @Mapping(target = "duplicate", source = "duplicate")
    @Mapping(target = "sessionId", source = "session.id")
    @Mapping(target = "chunkIndex", source = "chunkIndex")
    UploadChunkResponse toUploadChunkResponse(SyncSession session, Integer chunkIndex, Boolean duplicate);

}
